/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/search', 'N/record', 'N/log'], (search, record, log) => {

    const onRequest = (context) => {
        try {
            // if (context.request.method !== 'POST') {
            //     context.response.write(JSON.stringify({
            //         success: false,
            //         message: 'Use POST with Rocketlane payload.'
            //     }));
            //     return;
            // }

            // let payload;
            // try {
            //     payload = JSON.parse(context.request.body || '{}');
            // } catch (e) {
            //     context.response.write(JSON.stringify({
            //         success: false,
            //         message: 'Invalid JSON payload.'
            //     }));
            //     return;
            // }

            // const rocketlaneInvoiceId = payload.invoiceId;
            // const rocketlaneInvoiceId = 59179;
            const params = context.request.parameters || {};
            log.debug("params",params)
        const rocketlaneInvoiceId = params.rlInvoiceId || params.invoiceId || params.invoiceid;

            if (!rocketlaneInvoiceId) {
                context.response.write(JSON.stringify({
                    success: false,
                    message: 'invoiceId is missing in payload.'
                }));
                return;
            }

            // OPTIONAL: Process only VOIDED invoices
            // if (payload.status !== 'VOIDED') {
            //     context.response.write(JSON.stringify({
            //         success: false,
            //         message: 'Invoice is not VOIDED. Skipping.'
            //     }));
            //     return;
            // }

            log.debug('Rocketlane Invoice ID', rocketlaneInvoiceId);

            // 🔍 Search Invoice using custom body field
            const invoiceSearch = search.create({
                type: search.Type.INVOICE,
                filters: [
                    ['custbodyrocketlane_invoice_id', 'is', String(rocketlaneInvoiceId)],
                    'AND',
                    ['mainline', 'is', 'T']
                ],
                columns: ['internalid']
            });

            const results = invoiceSearch.run().getRange({ start: 0, end: 1 });

            if (!results || !results.length) {
                context.response.write(JSON.stringify({
                    success: false,
                    message: `No Invoice found for Rocketlane invoiceId ${rocketlaneInvoiceId}.`
                }));
                return;
            }

            const nsInvoiceId = Number(results[0].getValue({ name: 'internalid' }));

            log.debug('NetSuite Invoice ID', nsInvoiceId);

            // 🔄 Transform Invoice → Credit Memo
            const creditMemoRecord = record.transform({
                fromType: record.Type.INVOICE,
                fromId: nsInvoiceId,
                toType: record.Type.CREDIT_MEMO,
                isDynamic: true
            });

            creditMemoRecord.setValue({
                fieldId: 'memo',
                value: 'voided from Rocketlane'
            });

            const creditMemoId = creditMemoRecord.save();

            context.response.write(JSON.stringify({
                success: true,
                message: 'Credit Memo created successfully.',
                rocketlaneInvoiceId: rocketlaneInvoiceId,
                nsInvoiceId: nsInvoiceId,
                creditMemoId: creditMemoId
            }));

        } catch (error) {
            log.error({
                title: 'Error creating Credit Memo',
                details: error
            });

            context.response.write(JSON.stringify({
                success: false,
                message: error.message || String(error)
            }));
        }
    };

    return { onRequest };
});