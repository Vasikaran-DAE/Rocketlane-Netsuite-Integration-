/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
define([
    'N/record',
    'N/search',
    'N/https',
    'N/log'
], (record, search, https, log) => {

    const RL_BASE_URL = 'https://at-bay-test.api.rocketlane.com/api/v1/expenses';
    const RL_EXPENSE_REPORTS_URL = 'https://at-bay-test.api.rocketlane.com/api/v1/expense-reports';
    const RL_API_KEY = 'rl-7d47f3ce-82a2-4825-8f1e-bac8dbabaf6a';
    const RL_SUBMIT_APPROVAL = 'https://at-bay-test.api.rocketlane.com/api/v1/expense-reports';
    // projects endpoint (using same test host as other endpoints)
    const RL_PROJECTS_URL = 'https://at-bay-test.api.rocketlane.com/api/1.0/projects';

    const buildHeaders = () => ({
        accept: 'application/json',
        'content-type': 'application/json',
        'api-key': RL_API_KEY
    });

    const toISODate = (value) => {
        if (!value) return null;
        const d = new Date(value);
        return isNaN(d) ? null : d.toISOString().split('T')[0];
    };

    const createExpenseReport = (payload) => {
        try {
            const resp = https.request({
                method: https.Method.POST,
                url: RL_EXPENSE_REPORTS_URL,
                headers: buildHeaders(),
                body: JSON.stringify(payload)
            });

            if (resp && (resp.code === 200 || resp.code === 201) && resp.body) {
                return JSON.parse(resp.body);
            }

            log.error('createExpenseReport failed', { payload, resp });
            return null;

        } catch (e) {
            log.error('createExpenseReport exception', e);
            return null;
        }
    };

    const createExpense = (payload) => {
        try {
            const resp = https.request({
                method: https.Method.POST,
                url: RL_BASE_URL,
                headers: buildHeaders(),
                body: JSON.stringify(payload)
            });

            if (resp && (resp.code === 200 || resp.code === 201)) {
                return resp.body ? JSON.parse(resp.body) : {};
            }

            log.error('createExpense failed', { payload, resp });
            return null;

        } catch (e) {
            log.error('createExpense exception', e);
            return null;
        }
    };

    const approveExpenseReport = (expenseReportId) => {
        try {
            const resp = https.request({
                method: https.Method.POST,
                url: RL_SUBMIT_APPROVAL + '/' + expenseReportId + "/submit",
                headers: buildHeaders(),
                body: {}
            });

            return resp && (resp.code === 200 || resp.code === 201 || resp.code === 204);

        } catch (e) {
            log.error('approveExpenseReport exception', e);
            return false;
        }
    };

    const getProjectIdByCustomerDisplay = (customerDisplay) => {
        try {
            if (!customerDisplay) return null;

            // remove leading numbers and spaces, e.g. "43267 Harrison..." -> "Harrison..."
            const projectName = String(customerDisplay).replace(/^\s*\d+\s*/, '').trim();
            if (!projectName) return null;

            const url = RL_PROJECTS_URL + '?includeAllFields=true&projectName.cn=' + encodeURIComponent(projectName + ' - Recovery');

            const resp = https.request({
                method: https.Method.GET,
                url,
                headers: buildHeaders()
            });

            if (!resp || resp.code !== 200 || !resp.body) {
                log.debug('getProjectIdByCustomerDisplay no-result', { projectName, respCode: resp && resp.code });
                return null;
            }
             log.debug("resp",resp)
            let body;
            try {
                body = JSON.parse(resp.body);
            } catch (e) {
                log.error('getProjectIdByCustomerDisplay json-parse-error', { projectName, error: e });
                return null;
            }

            // Response shape may vary (array or object). Try common fields defensively.
            if (Array.isArray(body) && body.length > 0) {
                const first = body[0];
                return first.id || first.projectId || first.internalId || null;
            }

            // Sometimes API returns an object with 'data' or 'projects' array
            if (body && Array.isArray(body.data) && body.data.length > 0) {
                const first = body.data[0];
                return first.id || first.projectId || first.internalId || null;
            }

            if (body && Array.isArray(body.projects) && body.projects.length > 0) {
                const first = body.projects[0];
                return first.id || first.projectId || first.internalId || null;
            }

            // Or a single object
            if (body && (body.id || body.projectId || body.internalId)) {
                return body.id || body.projectId || body.internalId;
            }

            log.debug('getProjectIdByCustomerDisplay not-found', { projectName, body });
            return null;

        } catch (e) {
            log.error('getProjectIdByCustomerDisplay exception', e);
            return null;
        }
    };

    const getInputData = () => {
        log.debug("getInputData")
        return search.create({
            type: search.Type.EXPENSE_REPORT,   // ✅ Changed from VENDOR_BILL
            filters: [
                ['mainline', 'is', 'T'],
                'AND',
                ['custbodysynced_to_rocketlane', 'is', 'F'],
                'AND',
                ["status","anyof","ExpRept:F"], 
                 "AND",
                ['subsidiary', 'anyof', '13'],
                'AND',
                ['trandate', 'onorafter', '1/31/2026'],
                 "AND", 
               ["customform","anyof","46"]
            ],
            columns: ['internalid']
        });
    };

    const map = (context) => {
log.debug("contexr",context)
        const searchResult = JSON.parse(context.value);
        const expenseReportNsId = searchResult.id;
        let anySuccess = false;

        try {

            const expenseReport = record.load({
                type: record.Type.EXPENSE_REPORT,  // ✅ Changed from VENDOR_BILL
                id: expenseReportNsId,
                isDynamic: false
            });

            // const tranDate = toISODate(expenseReport.getValue('trandate'));

            const processSublist = (sublistId, memoField) => {

                const lineCount = expenseReport.getLineCount({ sublistId }) || 0;

                for (let i = 0; i < lineCount; i++) {

                    const amount = expenseReport.getSublistValue({
                        sublistId,
                        fieldId: 'amount',
                        line: i
                    });
 
                   const tranDate = expenseReport.getSublistValue({
                        sublistId,
                        fieldId: 'expensedate',
                        line: i
                    });

                    if (!amount || Number(amount) <= 0) continue;

                    const lineMemo = expenseReport.getSublistValue({
                        sublistId,
                        fieldId: memoField,
                        line: i
                    }) || '';

                    // NEW: get customer_display from line-level and resolve projectId dynamically
                    const customerDisplay = expenseReport.getSublistValue({
                        sublistId,
                        fieldId: 'customer_display',
                        line: i
                    }) || '';

                    // try to resolve projectId from Rocketlane, fallback to static
                    const resolvedProjectId = getProjectIdByCustomerDisplay(customerDisplay) ;

                    const expenseReportPayload = {
                        expenseReportName: lineMemo ,
                        projectId: resolvedProjectId,
                        expenseOwnerId: 600280
                    };

                    const expenseReportResp = createExpenseReport(expenseReportPayload);
                    log.debug("expenseReportResp", expenseReportResp);

                    const expenseReportId =
                        expenseReportResp &&
                        (expenseReportResp.expenseReportId || expenseReportResp.id);

                    if (!expenseReportId) {
                        log.error('Expense Report creation failed', { expenseReportNsId, line: i });
                        continue;
                    }

                    const payload = {
                        amount: Number(amount),
                        currency: {
                            currencyCode: 'USD',
                            currencyName: 'US Dollar',
                            currencySymbol: '$'
                        },
                        date: tranDate,
                        status: 'DRAFT',
                        expenseOwnerId: 600280,
                        projectId: resolvedProjectId,
                        expenseCategoryId: "",
                        expenseReportId: expenseReportId,
                        reimbursable: false,
                        billable: true,
                        note: lineMemo,
                        attachments: [],
                        createdBy: 600280,
                        fields: [
                            { fieldId: 2269384, fieldValue: lineMemo },
                            { fieldId: 2270224, fieldValue: expenseReportNsId },
                            { fieldId: 2277751, fieldValue: 'expense_report' }
                        ],
                        // projectFinancialsBudgetId: 314608
                    };

                    const expenseResp = createExpense(payload);

                    if (!expenseResp) {
                        log.error('Expense creation failed', { expenseReportNsId, line: i });
                        continue;
                    }

                    approveExpenseReport(expenseReportId);

                    anySuccess = true;
                }
            };

            // Process expense lines (Expense Reports use 'expense' sublist)
            processSublist('expense', 'memo');

            if (anySuccess) {
                context.write({ key: expenseReportNsId, value: true });
            }

        } catch (e) {
            log.error('Map Error', { expenseReportNsId, error: e });
        }
    };

    const reduce = (context) => {

        const expenseReportNsId = context.key;

        try {
            record.submitFields({
                type: record.Type.EXPENSE_REPORT,  // ✅ Changed
                id: expenseReportNsId,
                values: {
                    custbodysynced_to_rocketlane: true
                },
                options: {
                    enableSourcing: false,
                    ignoreMandatoryFields: true
                }
            });

        } catch (e) {
            log.error('Reduce Error', { expenseReportNsId, error: e });
        }
    };

    return {
        getInputData,
        map,
        reduce
    };
});
