/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
define([
    'N/record',
    'N/search',
    'N/https',
    'N/log'
], (record, search, https, log) => {

    const RL_BASE_URL = 'https://at-bay-test.api.rocketlane.com/api/v1/expenses';
    const RL_EXPENSE_REPORTS_URL = 'https://at-bay-test.api.rocketlane.com/api/v1/expense-reports';
    const RL_API_KEY = 'rl-7d47f3ce-82a2-4825-8f1e-bac8dbabaf6a';
    const RL_SUBMIT_APPROVAL = 'https://at-bay-test.api.rocketlane.com/api/v1/expense-reports';
    const RL_PROJECTS_URL = 'https://at-bay-test.api.rocketlane.com/api/1.0/projects';

    const buildHeaders = () => ({
        accept: 'application/json',
        'content-type': 'application/json',
        'api-key': RL_API_KEY
    });

    const toISODate = (value) => {
        if (!value) return null;
        const d = new Date(value);
        return isNaN(d) ? null : d.toISOString().split('T')[0];
    };

    const createExpenseReport = (payload) => {
        try {
            const resp = https.request({
                method: https.Method.POST,
                url: RL_EXPENSE_REPORTS_URL,
                headers: buildHeaders(),
                body: JSON.stringify(payload)
            });

            if (resp && (resp.code === 200 || resp.code === 201) && resp.body) {
                return JSON.parse(resp.body);
            }

            log.error('createExpenseReport failed', { payload, resp });
            return null;

        } catch (e) {
            log.error('createExpenseReport exception', e);
            return null;
        }
    };

    const createExpense = (payload) => {
        try {
            const resp = https.request({
                method: https.Method.POST,
                url: RL_BASE_URL,
                headers: buildHeaders(),
                body: JSON.stringify(payload)
            });

            if (resp && (resp.code === 200 || resp.code === 201)) {
                return resp.body ? JSON.parse(resp.body) : {};
            }

            log.error('createExpense failed', { payload, resp });
            return null;

        } catch (e) {
            log.error('createExpense exception', e);
            return null;
        }
    };

    const approveExpenseReport = (expenseReportId) => {
        try {
            const resp = https.request({
                method: https.Method.POST,
                url: RL_SUBMIT_APPROVAL + '/' + expenseReportId + "/submit",
                headers: buildHeaders(),
                body: {}
            });

            return resp && (resp.code === 200 || resp.code === 201 || resp.code === 204);

        } catch (e) {
            log.error('approveExpenseReport exception', e);
            return false;
        }
    };

    // 🔹 Dynamic Project Resolver (same logic as your other script)
    const getProjectIdByCustomerDisplay = (customerDisplay) => {
        try {
            log.debug("customerDisplay",customerDisplay)
            if (!customerDisplay) return null;

            const projectName = String(customerDisplay)
                .replace(/^\s*\d+\s*/, '')
                .trim();
                 log.debug("projectName",projectName)
            if (!projectName) return null;
                 
            const url = RL_PROJECTS_URL +
                '?includeAllFields=true&projectName.cn=' +
                encodeURIComponent(projectName + ' - Recovery');

            const resp = https.request({
                method: https.Method.GET,
                url,
                headers: buildHeaders()
            });
       log.debug("resp",resp);

            if (!resp || resp.code !== 200 || !resp.body) {
                return null;
            }

            const body = JSON.parse(resp.body);
       log.debug("body",body);
            if (Array.isArray(body) && body.length > 0) {
                return body[0].id || body[0].projectId || null;
            }

            if (body && Array.isArray(body.data) && body.data.length > 0) {
                return body.data[0].id || body.data[0].projectId || null;
            }

            if (body && body.id) {
                return body.id;
            }

            return null;

        } catch (e) {
            log.error('getProjectIdByCustomerDisplay exception', e);
            return null;
        }
    };

    const getInputData = () => {
        return search.create({
            type: search.Type.VENDOR_BILL,
            filters: [
                ['mainline', 'is', 'T'],
                'AND',
                ['custbodysynced_to_rocketlane', 'is', 'F'],
                'AND',
                ['approvalstatus', 'anyof', '2'],
                'AND',
                ['subsidiary', 'anyof', '13'],
                'AND',
                ['trandate', 'onorafter', '1/31/2026'],
                   "AND", 
               ["customform","anyof","134"]
            ],
            columns: ['internalid']
        });
    };

    const map = (context) => {

        const searchResult = JSON.parse(context.value);
        const billId = searchResult.id;
        let anySuccess = false;

        try {

            const bill = record.load({
                type: record.Type.VENDOR_BILL,
                id: billId,
                isDynamic: false
            });

            const tranDate = toISODate(bill.getValue('trandate'));

            const processSublist = (sublistId, memoField) => {

                const lineCount = bill.getLineCount({ sublistId }) || 0;

                for (let i = 0; i < lineCount; i++) {

                    const amount = bill.getSublistValue({
                        sublistId,
                        fieldId: 'amount',
                        line: i
                    });

                    if (!amount || Number(amount) <= 0) continue;

                    const lineMemo = bill.getSublistValue({
                        sublistId,
                        fieldId: memoField,
                        line: i
                    }) || '';

                    // 🔹 Get customer_display from line
                    const customerDisplay = bill.getSublistValue({
                        sublistId,
                        fieldId: 'customer_display',
                        line: i
                    }) || '';

                    const resolvedProjectId =
                        getProjectIdByCustomerDisplay(customerDisplay) ;

                    const expenseReportPayload = {
                        expenseReportName: lineMemo,
                        projectId: resolvedProjectId,
                        expenseOwnerId: 600280
                    };

                    const expenseReportResp = createExpenseReport(expenseReportPayload);

                    const expenseReportId =
                        expenseReportResp &&
                        (expenseReportResp.expenseReportId || expenseReportResp.id);

                    if (!expenseReportId) {
                        log.error('Expense Report creation failed', { billId, line: i });
                        continue;
                    }

                    const payload = {
                        amount: Number(amount),
                        currency: {
                            currencyCode: 'USD',
                            currencyName: 'US Dollar',
                            currencySymbol: '$'
                        },
                        date: tranDate,
                        status: 'DRAFT',
                        expenseOwnerId: 600280,
                        projectId: resolvedProjectId,
                        expenseCategoryId: "",
                        expenseReportId: expenseReportId,
                        reimbursable: false,
                        billable: true,
                        note: lineMemo,
                        attachments: [],
                        createdBy: 600280,
                        fields: [
                            { fieldId: 2269384, fieldValue: lineMemo },
                            { fieldId: 2270224, fieldValue: billId },
                            { fieldId: 2277751, fieldValue: 'bill' }
                        ],
                        // projectFinancialsBudgetId: 314608
                    };

                    const expenseResp = createExpense(payload);

                    if (!expenseResp) {
                        log.error('Expense creation failed', { billId, line: i });
                        continue;
                    }

                    approveExpenseReport(expenseReportId);

                    anySuccess = true;
                }
            };

            processSublist('expense', 'memo');
            processSublist('item', 'description');

            if (anySuccess) {
                context.write({ key: billId, value: true });
            }

        } catch (e) {
            log.error('Map Error', { billId, error: e });
        }
    };

    const reduce = (context) => {

        const billId = context.key;

        try {
            record.submitFields({
                type: record.Type.VENDOR_BILL,
                id: billId,
                values: {
                    custbodysynced_to_rocketlane: true
                },
                options: {
                    enableSourcing: false,
                    ignoreMandatoryFields: true
                }
            });

        } catch (e) {
            log.error('Reduce Error', { billId, error: e });
        }
    };

    return {
        getInputData,
        map,
        reduce
    };
});
