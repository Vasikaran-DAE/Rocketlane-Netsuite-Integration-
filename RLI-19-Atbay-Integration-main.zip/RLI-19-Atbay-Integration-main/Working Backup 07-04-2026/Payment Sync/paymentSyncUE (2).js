/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define([
    'N/record',
    'N/https',
    'N/log',
    'N/format'
], (record, https, log, format) => {

    const RL_BASE_URL = 'https://at-bay-test.api.rocketlane.com/api/v1/invoices';
    // Put your Rocketlane API key here or read from a script parameter / secure store
    const RL_API_KEY = 'rl-7d47f3ce-82a2-4825-8f1e-bac8dbabaf6a';

    /**
     * Convert a JS Date (or NetSuite date object) to YYYY-MM-DD
     * If value is a string, attempt to create Date first.
     */
  
    function toISODateString(value) {
        if (!value) return null;
        let d = value;
        if (typeof value === 'string') d = new Date(value);
        if (!(d instanceof Date) || isNaN(d.getTime())) return null;
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
    }

    /**
     * Build headers used for Rocketlane API call
     */
    function buildHeaders() {
        return {
            'accept': 'application/json, text/plain, */*',
            'content-type': 'application/json',
            'api-key': RL_API_KEY
        };
    }

    /**
     * Send payment to Rocketlane for a single rlinvoiceId
     * Returns the HTTPS response object
     */
    function sendPaymentToRocketlane(rlInvoiceId, payload) {
        const url = `${RL_BASE_URL}/${encodeURIComponent(String(rlInvoiceId))}/payments`;
        try {
            const response = https.request({
                method: https.Method.POST,
                url: url,
                headers: buildHeaders(),
                body: JSON.stringify(payload)
            });
            return response;
        } catch (err) {
            log.error('Rocketlane HTTP Error', `rlInvoiceId=${rlInvoiceId} error=${err}`);
            throw err;
        }
    }

    /**
     * afterSubmit entrypoint
     */
    function afterSubmit(context) {
        try {
            if (context.type !== context.UserEventType.CREATE) {
                log.debug('Skipping', 'Only running on create events');
                return;
            }

            const paymentId = context.newRecord.id;
            const paymentRec = record.load({
                type: record.Type.CUSTOMER_PAYMENT,
                id: paymentId,
                isDynamic: false
            });

            // Prepare payload fields common to all invoices
            const trandateValue = paymentRec.getValue({ fieldId: 'trandate' });
            const entryDate = toISODateString(trandateValue) || null;

            // Try multiple possible amount fields commonly used for customer payment
            const amountValue = paymentRec.getValue({ fieldId: 'payment' })
                || paymentRec.getValue({ fieldId: 'total' })
                || paymentRec.getValue({ fieldId: 'amount' })
                || 0;

            // const memo = paymentRec.getValue({ fieldId: 'memo' }) || '';
   
          const paymentCard = paymentRec.getText({
                        fieldId: 'paymentoption',
          })
          log.debug("paymentCard",paymentCard)
            const applyLineCount = paymentRec.getLineCount({ sublistId: 'apply' }) || 0;

            let anySuccess = false;
            const errors = [];

            for (let i = 0; i < applyLineCount; i++) {
                try {
                    const isApplied = paymentRec.getSublistValue({
                        sublistId: 'apply',
                        fieldId: 'apply',
                        line: i
                    });

                    // Only process applied invoices
                    if (!isApplied) continue;

                    // 'doc' on apply sublist is the internal id of the invoice
                    const invoiceInternalId = paymentRec.getSublistValue({
                        sublistId: 'apply',
                        fieldId: 'doc',
                        line: i
                    });

                    if (!invoiceInternalId) {
                        log.debug('No invoice internal id on apply line', `line=${i}`);
                        continue;
                    }
                  const invoiceAmt = paymentRec.getSublistValue({
                        sublistId: 'apply',
                        fieldId: 'amount',
                        line: i
                    });
 
             const payloadBase = {
                entryDate: entryDate,
                amount: String(invoiceAmt),
                notes: paymentCard,
                paymentRecordType: 'PAID'
                };
              log.debug("payloadBase in for loop",payloadBase)
                    // Load the invoice and read the externalid (this is the Rocketlane invoice id per your note)
                    let invoiceRec;
                    try {
                        invoiceRec = record.load({
                            type: record.Type.INVOICE,
                            id: invoiceInternalId,
                            isDynamic: false
                        });
                    } catch (e) {
                        log.error('Invoice Load Failed', `internalId=${invoiceInternalId} error=${e}`);
                        errors.push(`Invoice load failed: ${invoiceInternalId} -> ${e}`);
                        continue;
                    }

                    const rlInvoiceId = invoiceRec.getValue({ fieldId: 'custbodyrocketlane_invoice_id' });
                    if (!rlInvoiceId) {
                        log.debug('No externalid on invoice', `invoiceInternalId=${invoiceInternalId}`);
                        continue;
                    }

                    // Build payload (if you need to override amount per invoice you can customize here)
                    const payload = Object.assign({}, payloadBase);

                    log.debug('Sending to Rocketlane', `rlInvoiceId=${rlInvoiceId} payload=${JSON.stringify(payload)}`);

                    const resp = sendPaymentToRocketlane(rlInvoiceId, payload);

                    // Consider 200 or 201 as success
                    if (resp && (resp.code === 200 || resp.code === 201 || resp.code === 204)) {
                        log.audit('Rocketlane Payment Synced', `invoice ${rlInvoiceId} -> response ${resp.code}`);
                        anySuccess = true;
                    } else {
                        log.error('Rocketlane Payment Failed', `invoice ${rlInvoiceId} -> code ${resp && resp.code} body ${resp && resp.body}`);
                        errors.push(`rlInvoice ${rlInvoiceId} failed status=${resp && resp.code}`);
                    }

                } catch (innerErr) {
                    log.error('Error processing apply line', `line ${i} error: ${innerErr}`);
                    errors.push(`apply line ${i} error: ${innerErr}`);
                }
            } // end for apply lines

            // If at least one succeeded, mark the payment record checkbox as synced
            if (anySuccess) {
                try {
                    record.submitFields({
                        type: record.Type.CUSTOMER_PAYMENT,
                        id: paymentId,
                        values: {
                            custbodysynced_to_rocketlane: true
                        },
                        options: {
                            enableSourcing: false,
                            ignoreMandatoryFields: true
                        }
                    });
                    log.audit('Marked Synced', `Customer Payment ${paymentId} custbodysynced_to_rocketlane = true`);
                } catch (submitErr) {
                    log.error('Failed to mark synced checkbox', `paymentId=${paymentId} error=${submitErr}`);
                    // Not throwing - we already sent to Rocketlane; but log
                }
            } else {
                log.debug('No successful Rocketlane updates', `errors: ${JSON.stringify(errors)}`);
            }

        } catch (err) {
            log.error('afterSubmit Error', err);
            // Do not throw to avoid breaking NetSuite save flow — optional: rethrow if desired
        }
    }

    return {
        afterSubmit
    };
});
