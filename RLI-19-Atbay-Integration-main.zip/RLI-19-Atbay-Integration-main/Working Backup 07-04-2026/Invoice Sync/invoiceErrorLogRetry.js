/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define([
    'N/https',
    'N/log',
    'SuiteScripts/Library/moment.js',
    "SuiteScripts/rocketlaneInvoiceModule.js",
    "N/redirect",
    "N/record"
], function (https, log, moment, rocketLane, redirect, record) {


    const PARAM_API_KEY = 'rl-7d47f3ce-82a2-4825-8f1e-bac8dbabaf6a';
    const ROCKETLANE_BASE = 'https://at-bay-test.api.rocketlane.com/api/v1/invoices/';

    // removed pending = 3 (no longer used)
    var STATUS_FAILED = 2;

    function onRequest(context) {
        const req = context.request;
        const res = context.response;
        const errorLogId = req.parameters.rec_id;
        log.debug("errorLogId -=>", errorLogId);

        if (!errorLogId) {
            return redirectToRec(errorLogId)
        }

        const errorLogRec = record.load({
            type: "customrecord_rl_invoice_log",
            id: errorLogId
        })
        var oldPayLoad = errorLogRec.getValue("custrecord_rl_response")
        oldPayLoad = oldPayLoad ? JSON.stringify(JSON.parse(oldPayLoad), null, 2) : ""


        try {


            try { res.setHeader({ name: 'Content-Type', value: 'application/json' }); } catch (e) { }

            let params = req.parameters || {};
            let body = {};
            if (req.method === 'POST' && req.body) {
                try {
                    body = JSON.parse(req.body);
                }
                catch (e) {
                    body = {};
                    req.body.split('&').forEach(function (pair) {
                        const [k, v] = pair.split('=');
                        if (k) body[decodeURIComponent(k)] = decodeURIComponent((v || '').replace(/\+/g, ' '));
                    });
                }
            }

            const rlInvoiceId = (params.invoiceid || params.invoiceId || body.invoiceid || body.invoiceId);

            log.debug("rlInvoiceId ==>", rlInvoiceId);


            if (!rlInvoiceId) {
                rocketLane.updateLogRecord(errorLogId, oldPayLoad, 2, 'Missing invoiceId parameter.')
                return redirectToRec(errorLogId)
            }

            const apiKey = PARAM_API_KEY;

            if (!apiKey) {
                rocketLane.updateLogRecord(errorLogId, oldPayLoad, 2, 'Rocketlane API key not set. Add script parameter: ' + PARAM_API_KEY)
                return redirectToRec(errorLogId)
            }

            // Fetch Rocketlane invoice
            const rlResp = https.request({
                method: https.Method.GET,
                url: ROCKETLANE_BASE + encodeURIComponent(rlInvoiceId),
                headers: {
                    accept: 'application/json',
                    'api-key': apiKey
                }
            });

            log.debug("rlResp", rlResp)

            if (rlResp.code !== 200) {
                const errMsg = 'Rocketlane API returned code ' + rlResp.code + ' body: ' + rlResp.body;
                log.error('Rocketlane API error', errMsg);
                rocketLane.updateLogRecord(errorLogId, oldPayLoad, 2, errMsg)
                return redirectToRec(errorLogId)

            }

            const payload = JSON.parse(rlResp.body || '{}');
            log.debug("payload", payload)

            // check existing log
            const existingLog = rocketLane.findLogByInvoiceId(rlInvoiceId);
            log.debug('existingLog ==>', existingLog);

            if (existingLog) {
                // previously used pending; now just update info (no status change yet)
                // const logRecId = rocketLane.updateLogRecord(existingLog.id, payload, null, null);

                const createResult = rocketLane.createInvoice(payload);
                rocketLane.finalizeLogWithCreateResult(errorLogId, createResult, rlInvoiceId);

                return redirectToRec(errorLogId);

            } else {
                // new RL invoice - create log, attempt create
                // const logRecId = rocketLane.upsertLogRecord(rlInvoiceId, payload, null, JSON.stringify(payload), null);
                const createResult = rocketLane.createInvoice(payload);
                rocketLane.finalizeLogWithCreateResult(errorLogId, createResult, rlInvoiceId);
                return redirectToRec(errorLogId);
            }

        } catch (e) {
            log.error('Suitelet error', e);

            return redirectToRec(errorLogId)
            // try { res.setHeader({ name: 'Content-Type', value: 'application/json' }); } catch (er) { }

            // res.write(JSON.stringify({ success: false, error: e.message || String(e) }));
        }
    }

    function redirectToRec(id) {
        return redirect.toRecord({
            type: "customrecord_rl_invoice_log",
            id: id
        });
    }


    return {
        onRequest: onRequest
    };
});
