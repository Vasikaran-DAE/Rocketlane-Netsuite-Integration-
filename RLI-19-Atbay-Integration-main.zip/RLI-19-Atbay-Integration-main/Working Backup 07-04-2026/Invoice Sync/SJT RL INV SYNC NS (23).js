/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define([
    'N/https',
    'N/record',
    'N/search',
    'N/log',
    'N/runtime',
    'N/email',
    'SuiteScripts/Library/moment.js'
], function (https, record, search, log, runtime,email, moment) {

    const CUSTOM_LOG_REC = 'customrecord_rl_invoice_log';
    const PARAM_API_KEY = 'rl-7d47f3ce-82a2-4825-8f1e-bac8dbabaf6a';
    const ROCKETLANE_BASE = 'https://at-bay-test.api.rocketlane.com/api/v1/invoices/';

    // removed pending = 3 (no longer used)
    const STATUS_SUCCESS = 1;
    const STATUS_FAILED = 2;

    function onRequest(context) {
        const req = context.request;
        const res = context.response;

        try {
            try { res.setHeader({ name: 'Content-Type', value: 'application/json' }); } catch (e) { }

            let params = req.parameters || {};
            let body = {};
            if (req.method === 'POST' && req.body) {
                try { body = JSON.parse(req.body); } catch (e) {
                    body = {};
                    req.body.split('&').forEach(function (pair) {
                        const [k, v] = pair.split('=');
                        if (k) body[decodeURIComponent(k)] = decodeURIComponent((v || '').replace(/\+/g, ' '));
                    });
                }
            }

            const rlInvoiceId = (params.invoiceid || params.invoiceId || body.invoiceid || body.invoiceId);
            log.debug("rlInvoiceId ==>", rlInvoiceId);

            const force = (params.force || body.force || '').toString().toLowerCase();
            const doForce = (force === '1' || force === 'true');

            if (!rlInvoiceId) {
                res.write(JSON.stringify({ success: false, error: 'Missing invoiceId parameter.' }));
                return;
            }

            const apiKey = PARAM_API_KEY;
            if (!apiKey) {
                res.write(JSON.stringify({ success: false, error: 'Rocketlane API key not set. Add script parameter: ' + PARAM_API_KEY }));
                return;
            }

            // Fetch Rocketlane invoice
            const rlResp = https.request({
                method: https.Method.GET,
                url: ROCKETLANE_BASE + encodeURIComponent(rlInvoiceId),
                headers: {
                    accept: 'application/json',
                    'api-key': apiKey
                }
            });

            log.debug("rlResp", rlResp)

            if (rlResp.code !== 200) {
                const errMsg = 'Rocketlane API returned code ' + rlResp.code + ' body: ' + rlResp.body;
                log.error('Rocketlane API error', errMsg);
                const logRecId = upsertLogRecord(rlInvoiceId, null, STATUS_FAILED, rlResp.body, errMsg);
                res.write(JSON.stringify({ success: false, error: errMsg, logRecId }));
                return;
            }

            const payload = JSON.parse(rlResp.body || '{}');
            log.debug("payload", payload)

            // check existing log
            const existingLog = findLogByInvoiceId(rlInvoiceId);
            log.debug('existingLog ==>', existingLog)
            if (existingLog) {
                // previously used pending; now just update info (no status change yet)
                const logRecId = updateLogRecord(existingLog.id, payload, null, null);
                if (!doForce) {
                    res.write(JSON.stringify({
                        success: true,
                        message: 'Existing Rocketlane invoice found in log — updated log only. Call again with force=1 to force invoice creation.',
                        logRecId,
                        rlInvoiceId
                    }));
                    return;
                } else {
                    // force create even though log exists
                    const createResult = attemptCreateInvoice(payload);
                    finalizeLogWithCreateResult(logRecId, createResult,rlInvoiceId);
                    res.write(JSON.stringify({ success: !!createResult.success, result: createResult, logRecId, rlInvoiceId }));
                    return;
                }
            } else {
                // new RL invoice - create log, attempt create
                const logRecId = upsertLogRecord(rlInvoiceId, payload, null, JSON.stringify(payload), null);
                const createResult = attemptCreateInvoice(payload);
                finalizeLogWithCreateResult(logRecId, createResult,rlInvoiceId);
                res.write(JSON.stringify({ success: !!createResult.success, result: createResult, logRecId, rlInvoiceId }));
                return;
            }

        } catch (e) {
            log.error('Suitelet error', e);
            try { res.setHeader({ name: 'Content-Type', value: 'application/json' }); } catch (er) { }
            res.write(JSON.stringify({ success: false, error: e.message || String(e) }));
        }
    }

    // --- helper functions ---
    function attemptCreateInvoice(payload) {
        try {
            const invoiceId = payload.invoiceId || null
            const invoiceNumber = (payload.invoiceNumberPrefix || '') + (payload.invoiceNumber || '');
            const trandate = payload.dateOfIssue || null;
            const dueDate = payload.dueDate || null;
            const toCompanyName = (payload.toCompany && payload.toCompany.companyName) ? payload.toCompany.companyName : null;
            const projectName = (payload.invoiceToSourceMappings && payload.invoiceToSourceMappings[0] && payload.invoiceToSourceMappings[0].project && payload.invoiceToSourceMappings[0].project.projectName) ? payload.invoiceToSourceMappings[0].project.projectName : '';
            const amount = payload.amount || payload.subTotal || 0;

            // let claimNumber = null;
            // let itemLabel = null;
            // if (Array.isArray(payload.fields)) {
            //     payload.fields.forEach(function (f) {
            //         if (f.fieldId === 2097528) claimNumber = f.fieldValue;
            //         if (f.fieldId === 2097531) {
            //             if (f.metaFieldValue && f.metaFieldValue[0] && f.metaFieldValue[0].label) itemLabel = f.metaFieldValue[0].label;
            //         }
            //     });
            // }
            let claimNumber = null;
          let itemLabel = null;

if (Array.isArray(payload.fields)) {
    payload.fields.forEach(function (f) {

        // Claim # fieldId from Rocketlane
        if (f.fieldId === 2284220) {
            claimNumber = f.fieldValue;
        }

        // Incident Type fieldId
        if (f.fieldId === 2097531) {
            if (f.metaFieldValue && f.metaFieldValue[0] && f.metaFieldValue[0].label) {
                itemLabel = f.metaFieldValue[0].label;
            }
        }

    });
}

            const customerId = findCustomerByName(toCompanyName);
            if (!customerId) {
                return { success: false, error: 'Customer not found in NetSuite for name: ' + toCompanyName };
            }

            const itemId = findServiceItemByName(itemLabel);
            if (!itemId) {
                return { success: false, error: 'Item (service) not found in NetSuite for label: ' + itemLabel };
            }

            const invRec = record.create({ type: record.Type.INVOICE, isDynamic: true });


            invRec.setValue({ fieldId: 'customform', value: 177 });
            invRec.setValue({ fieldId: 'custbody_rocketlane_invoice_number', value: invoiceNumber });
            if (trandate) invRec.setValue({ fieldId: 'trandate', value: toDate(trandate) });
            invRec.setValue({ fieldId: 'entity', value: customerId });
            invRec.setValue({ fieldId: 'custbodyrocketlane_invoice_id', value: invoiceId })
            if (dueDate) invRec.setValue({ fieldId: 'duedate', value: toDate(dueDate) });
            invRec.setValue({ fieldId: 'memo', value: projectName || '' });
            if (claimNumber !== null && typeof claimNumber !== 'undefined') invRec.setValue({ fieldId: 'custbody__pi_claim_number', value: claimNumber });
            invRec.setValue({ fieldId: 'subsidiary', value: 13 });
            invRec.setValue({ fieldId: 'class', value: 30 });
            invRec.setValue({ fieldId: 'location', value: 21 });

            invRec.selectNewLine({ sublistId: 'item' });
            invRec.setCurrentSublistValue({ sublistId: 'item', fieldId: 'item', value: itemId });
            invRec.setCurrentSublistValue({ sublistId: 'item', fieldId: 'quantity', value: 1 });
            invRec.setCurrentSublistValue({ sublistId: 'item', fieldId: 'rate', value: parseFloat(amount) || 0 });
            invRec.commitLine({ sublistId: 'item' });

            const savedId = invRec.save({ enableSourcing: true, ignoreMandatoryFields: false });
            log.audit('Invoice created', 'NS Invoice internal id: ' + savedId);
            return { success: true, invoiceId: savedId };

        } catch (err) {
            log.error('attemptCreateInvoice error', err);
            return { success: false, error: (err.message || JSON.stringify(err)) };
        }
    }

    function toDate(isoDateStr) {
        if (!isoDateStr) return null;
        // const d = new Date(isoDateStr + 'T00:00:00Z');
        const d = new Date(new moment(isoDateStr).utcOffset("+05:30"));
        // if (isNaN(d.getTime())) return new Date(isoDateStr);
        return d;
    }

    function findLogByInvoiceId(rlInvoiceId) {
        try {
            const srch = search.create({
                type: CUSTOM_LOG_REC,
                filters: [
                    ["custrecord_rl_invoiceid", "is", rlInvoiceId]
                ],
                columns: ['internalid', 'custrecord_rl_status']
            });
            const res = srch.run().getRange({ start: 0, end: 1 });
            log.debug("res", res)
            if (res && res.length) {
                return { id: res[0].getValue('internalid'), status: res[0].getValue('custrecord_rl_status') };
            }
            return null;
        } catch (error) {
            log.error("Error in findLogByInvoiceId", error)
            throw error
        }
    }

//     function sendFailureEmail(rlInvoiceId, logRecId, errorText) {
//     try {

//         const scriptUser = runtime.getCurrentUser();
//            log.debug("ScriptUsr",scriptUser)
//         email.send({
//             author: 2512779,
//             recipients: 'vasikaran.d@prateektechnosoft.com',
//             subject: 'Rocketlane Invoice Creation Failed',
//             body:
//                 'Rocketlane Invoice creation failed.\n\n' +
//                 'RL Invoice ID : ' + rlInvoiceId + '\n' +
//                 'Log Record ID : ' + logRecId + '\n' +
//                 'Error          : ' + (errorText || 'Unknown Error')
//         });

//         log.debug('Failure Email Sent',rlInvoiceId );

//     } catch (e) {
//         log.error('sendFailureEmail error', e);
//     }
// }

function sendFailureEmail(rlInvoiceId, logRecId, errorText) {
    try {

        log.debug('EMAIL STEP', 'Entered sendFailureEmail');

        var currentUser = runtime.getCurrentUser();
        log.debug('Script User', currentUser.id);

        email.send({
            author:  2512779 ,
            recipients: 'securityar@at-bay.com',
            subject: 'Rocketlane Invoice Creation Failed',
            body:
                'Rocketlane Invoice creation failed.\n\n' +
                'RL Invoice ID : ' + rlInvoiceId + '\n' +
                'Log Record ID : ' + logRecId + '\n' +
                'Error          : ' + errorText
        });

        log.audit('EMAIL SUCCESS', 'Failure email sent');

    } catch (e) {
        log.error('EMAIL FAILED', e);
    }
}

    function upsertLogRecord(rlInvoiceId, payload, status, responseToStore, errorToStore) {
        const rec = record.create({ type: CUSTOM_LOG_REC, isDynamic: true });
        rec.setValue({ fieldId: 'custrecord_rl_invoiceid', value: rlInvoiceId });
        // default to failed (2) if status not specified yet — ensures no “pending”
        rec.setValue({ fieldId: 'custrecord_rl_status', value: status || STATUS_FAILED });
        // if (responseToStore) rec.setValue({ fieldId: 'custrecord_rl_response', value: JSON.stringify(responseToStore, null, 2) });
        if (responseToStore) rec.setValue({ fieldId: 'custrecord_rl_response', value: JSON.stringify(responseToStore, null, 3) });
        if (errorToStore) rec.setValue({ fieldId: 'custrecord_rl_error', value: JSON.stringify(errorToStore, null, 2) || '' });
        if (payload && payload.toCompany && payload.toCompany.companyName) {
            rec.setValue({ fieldId: 'custrecord_rl_company_name', value: payload.toCompany.companyName });
        }
        const id = rec.save({ enableSourcing: false, ignoreMandatoryFields: true });
        log.audit('Created log record', id);
        return id;
    }

    function updateLogRecord(logRecId, payload, status, errorText) {
        const rec = record.load({ type: CUSTOM_LOG_REC, id: logRecId, isDynamic: false });
        if (status) rec.setValue({ fieldId: 'custrecord_rl_status', value: status });
        if (payload) rec.setValue({ fieldId: 'custrecord_rl_response', value: JSON.stringify(payload, null, 3) });
        if (errorText) rec.setValue({ fieldId: 'custrecord_rl_error', value: JSON.stringify(errorText, null, 2) || '' });
        if (payload && payload.toCompany && payload.toCompany.companyName) {
            rec.setValue({ fieldId: 'custrecord_rl_company_name', value: payload.toCompany.companyName });
        }
        const id = rec.save({ enableSourcing: false, ignoreMandatoryFields: true });
        log.audit('Updated log record', id);
        return id;
    }

    function finalizeLogWithCreateResult(logRecId, createResult,rlInvoiceId) {
        try {
            log.debug("rlInvoiceId",rlInvoiceId)
            const rec = record.load({ type: CUSTOM_LOG_REC, id: logRecId, isDynamic: false });
            if (createResult.success) {
                rec.setValue({ fieldId: 'custrecord_rl_status', value: STATUS_SUCCESS });
                rec.setValue({ fieldId: 'custrecord_rl_ns_invoice', value: createResult.invoiceId });
                rec.setValue({ fieldId: 'custrecord_rl_error', value: '' });
            } else {
                rec.setValue({ fieldId: 'custrecord_rl_status', value: STATUS_FAILED });
                rec.setValue({ fieldId: 'custrecord_rl_error', value: createResult.error || 'Unknown error' });
               var emailSent =  sendFailureEmail(rlInvoiceId,logRecId,createResult.error);
               log.debug("emailSent",emailSent);
            }
            rec.save({ enableSourcing: false, ignoreMandatoryFields: true });
        } catch (e) {
            log.error('finalizeLogWithCreateResult error', e);
        }
    }

    function findCustomerByName(name) {
        if (!name) return null;
        const srch = search.create({
            type: search.Type.CUSTOMER,
            filters: [['companyname', 'is', name]],
            columns: ['internalid']
        });
        const res = srch.run().getRange({ start: 0, end: 1 });
        if (res && res.length) return res[0].getValue('internalid');

        const srch2 = search.create({
            type: search.Type.CUSTOMER,
            filters: [['entityid', 'is', name]],
            columns: ['internalid']
        });
        const r2 = srch2.run().getRange({ start: 0, end: 1 });
        if (r2 && r2.length) return r2[0].getValue('internalid');

        return null;
    }

    function findServiceItemByName(label) {
        if (!label) return null;
        const srch = search.create({
            type: search.Type.ITEM,
            filters: [
                ['itemid', 'is', label],
                'AND',
                ['type', 'anyof', 'Service']
            ],
            columns: ['internalid']
        });
        const res = srch.run().getRange({ start: 0, end: 1 });
        if (res && res.length) return res[0].getValue('internalid');

        const srch2 = search.create({
            type: search.Type.ITEM,
            filters: [['itemid', 'contains', label]],
            columns: ['internalid']
        });
        const r2 = srch2.run().getRange({ start: 0, end: 1 });
        if (r2 && r2.length) return r2[0].getValue('internalid');

        return null;
    }

    return {
        onRequest: onRequest
    };
});
