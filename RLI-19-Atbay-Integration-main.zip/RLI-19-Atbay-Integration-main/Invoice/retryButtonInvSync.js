/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/url'], function (url) {

    function beforeLoad(context) {
        try {
            if (context.type !== context.UserEventType.VIEW && context.type !== context.UserEventType.EDIT) {
                return;
            }

            var rec = context.newRecord;
log.debug("rec",rec)
            var status = rec.getValue({ fieldId: 'custrecord_rl_status' });
            var rlResponse = rec.getValue({ fieldId: 'custrecord_rl_response' });
            var invoiceId = null;

            // Parse JSON field to extract invoiceId
            
                    // var parsed = JSON.parse(rlResponse);
                 var invoiceId = rec.getValue({ fieldId: 'custrecord_rl_invoiceid' });
                log.debug("invoiceId",invoiceId)
            
            // Show Retry button only if invoiceId found and status not success (1)
            if ( status == 1) {
                return;
            }

            // Build Suitelet URL
            var suiteletUrl = url.resolveScript({
                scriptId: 'customscript_sjt_rl_inv_sync_ns',      // your Suitelet script id
                deploymentId: 'customdeploy_sjt_rl_inv_sync_ns',  // your Suitelet deploy id
                returnExternalUrl: false
            });

            // Add invoiceid param
            suiteletUrl += '&invoiceid=' + encodeURIComponent(invoiceId);

            // Add Retry button that opens Suitelet in new tab
            context.form.addButton({
                id: 'custpage_retry',
                label: 'Retry',
                functionName: "window.open('" + suiteletUrl + "', '_self')"
            });

        } catch (e) {
            log.error('Error in beforeLoad', e);
        }
    }

    return {
        beforeLoad: beforeLoad
    };
});
