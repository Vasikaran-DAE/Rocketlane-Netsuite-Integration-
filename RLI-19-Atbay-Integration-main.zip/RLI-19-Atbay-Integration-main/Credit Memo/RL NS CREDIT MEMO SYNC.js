/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/https', 'N/record', 'N/search', 'N/log', 'N/runtime', 'SuiteScripts/Library/moment.js','N/redirect'],
    function (https, record, search, log, runtime, moment,redirect) {

        const CUSTOM_REC = 'customrecordrocketlane_credit_memo_sync';
        const PARAM_API_KEY = 'rl-7d47f3ce-82a2-4825-8f1e-bac8dbabaf6a';
        const ROCKETLANE_BASE = 'https://at-bay-test.api.rocketlane.com/api/v1/invoices/';
        const STATUS_SUCCESS = 1;
        const STATUS_FAILED = 2;

        function onRequest(context) {
            const req = context.request;
            const res = context.response;
            const errorLogId = context.request.parameters.rec_id;

            log.debug("errorLogId ==>", errorLogId)
            log.debug('Suitelet triggered');

            try {
                res.setHeader({ name: 'Content-Type', value: 'application/json' });

                let params = req.parameters || {};
                let body = {};

                if (req.method === 'POST' && req.body) {
                    log.debug('POST incoming');
                    try {
                        body = JSON.parse(req.body);
                    } catch (e) {
                        body = {};
                        req.body.split('&').forEach(function (pair) {
                            const [k, v] = pair.split('=');
                            if (k) body[decodeURIComponent(k)] = decodeURIComponent((v || '').replace(/\+/g, ' '));
                        });
                    }
                }


                if (!errorLogId) {
                    // --- For testing you had hardcoded invoice; prefer incoming param first ---
                    const rlInvoiceId = params.invoiceid || params.invoiceId || body.invoiceid || body.invoiceId ;

                    if (!rlInvoiceId) {
                        res.write(JSON.stringify({ success: false, error: 'Missing invoiceId parameter. Provide ?invoiceid or POST JSON {"invoiceId"}.' }));
                        return;
                    }

                    const apiKey = PARAM_API_KEY;
                    if (!apiKey) {
                        res.write(JSON.stringify({ success: false, error: 'Rocketlane API key not set.' }));
                        return;
                    }

                    // === Fetch write-off data from Rocketlane API ===
                    const url = `${ROCKETLANE_BASE}${encodeURIComponent(rlInvoiceId)}/payments`;
                    log.debug('Fetching Rocketlane write-offs', url);

                    const rlResp = https.request({
                        method: https.Method.GET,
                        url: url,
                        headers: { accept: 'application/json', 'api-key': apiKey }
                    });

                    if (rlResp.code !== 200) {
                        const errMsg = `Rocketlane API returned ${rlResp.code}: ${rlResp.body}`;
                        log.error('Rocketlane API Error', errMsg);
                        res.write(JSON.stringify({ success: false, error: errMsg }));
                        return;
                    }

                    const writeOffs = JSON.parse(rlResp.body || '[]');
                    if (!Array.isArray(writeOffs) || writeOffs.length === 0) {
                        res.write(JSON.stringify({ success: false, message: 'No write-off data found for invoice ' + rlInvoiceId }));
                        return;
                    }

                    const results = [];

                    for (let entry of writeOffs) {
                        // Guard each entry with try/catch so one failure doesn't stop others
                        try {
                            const amount = parseFloat(entry.amount) || 0;
                            const entryDate = entry.entryDate;
                            const paymentId = entry.invoicePaymentRecordId; // this is the write-off id we must dedupe on

                            log.audit('Processing write-off', `invoice=${rlInvoiceId} writeOffId=${paymentId} amount=${amount} date=${entryDate}`);

                            // If same invoice + same writeOff already processed, skip creating CM
                            const already = findExistingLog(rlInvoiceId, paymentId);
                            if (already) {
                                log.audit('Write-off already processed — skipping', `invoice=${rlInvoiceId} writeOffId=${paymentId} logId=${already.id}`);
                                results.push({
                                    success: false,
                                    rocketlaneInvoiceId: rlInvoiceId,
                                    invoicePaymentRecordId: paymentId,
                                    message: 'Write-off already processed, skipping.'
                                });
                                continue; // skip to next entry
                            }

                            // Create initial log record (new) for this invoice+writeOff
                            const initialLogId = createLogRecord(rlInvoiceId, entry, STATUS_SUCCESS, '', paymentId);
                            log.debug('Created initial log record', { logId: initialLogId, invoice: rlInvoiceId, writeOff: paymentId });

                            // === Find matching NetSuite invoice ===
                            const nsInvoice = findInvoiceByRocketlaneId(rlInvoiceId);
                            if (!nsInvoice) throw new Error('No NetSuite invoice found for Rocketlane invoiceId: ' + rlInvoiceId);

                            // === Transform to Credit Memo ===
                            let cmId = null;
                            try {
                                cmId = createCreditMemoFromInvoice(nsInvoice.id, entryDate, amount, paymentId);
                                log.audit('Credit Memo created', `Invoice ${rlInvoiceId} → CM ${cmId}`);
                            } catch (e) {
                                // Update log to failed
                                log.error('Failed to create Credit Memo', e);
                                if (initialLogId) updateLogStatus(initialLogId, STATUS_FAILED, e.message);
                                throw e; // bubble up to outer catch to record result
                            }

                            // Update the log with the created credit memo and writeOff id
                            try {
                                if (initialLogId && cmId) updateLogWithCreditMemo(initialLogId, cmId);
                            } catch (e) {
                                log.error('Failed updating log with credit memo', e);
                                // not fatal for restoring data — record the error and continue
                                updateLogStatus(initialLogId, STATUS_FAILED, 'Failed updating credit memo link: ' + e.message);
                            }

                            results.push({
                                success: true,
                                rocketlaneInvoiceId: rlInvoiceId,
                                invoicePaymentRecordId: paymentId,
                                creditMemoId: cmId,
                                logRecordId: initialLogId
                            });

                        } catch (err) {
                            log.error('Error processing write-off entry', err);
                            // Create or update a log indicating failure for this specific writeoff
                            try {
                                const paymentId = entry && entry.invoicePaymentRecordId;
                                const existing = findExistingLog(rlInvoiceId, paymentId);
                                if (existing) {
                                    updateLogStatus(existing.id, STATUS_FAILED, err.message || String(err));
                                } else {
                                    createLogRecord(rlInvoiceId, entry, STATUS_FAILED, err.message || String(err), entry && entry.invoicePaymentRecordId);
                                }
                            } catch (e) {
                                log.error('Failed to write failure log', e);
                            }

                            results.push({
                                success: false,
                                rocketlaneInvoiceId: rlInvoiceId,
                                error: err.message || String(err)
                            });
                        }
                    }
                    res.write(JSON.stringify({ success: true, invoiceId: rlInvoiceId, results }));
                } else {
                    log.debug("INSIDE ELSE")
                    var errorLogRecord = record.load({ type: CUSTOM_REC, id: errorLogId });
                    log.debug("errorlogRecord", errorLogRecord)
                    var creditMemoData = errorLogRecord.getValue({ fieldId: "custrecordrocketlane_response" })
                    log.debug("creditMemoData", creditMemoData)

                    creditMemoData = JSON.parse(creditMemoData)

                    var invoiceId = creditMemoData["invoiceId"];
                    // log.debug("ifconditioninvoiceId", invoiceId)
                    var entryDate = creditMemoData["entryDate"];
                    var amount = creditMemoData["amount"];
                    var paymentId = creditMemoData["invoicePaymentRecordId"];
                    invoiceId = findInvoiceByRocketlaneId(invoiceId)
                    log.debug("ifconditioninvoiceId--1", invoiceId)
                    // invoiceId = parseInt(invoiceId)
                    invoiceId = Number(invoiceId.id);
                    log.debug("ifconditioninvoiceId--2", invoiceId)
                    const creditMemoId = createCreditMemoFromInvoice(invoiceId, entryDate, amount, paymentId);
                    if (creditMemoId) {
                        updateLogWithCreditMemo(errorLogId, creditMemoId)
                    }
                    log.debug("crcreditMemoIde", creditMemoId)

                }


            } catch (e) {
                log.error('Suitelet Error', e);
                res.write(JSON.stringify({ success: false, error: e.message || String(e) }));
            }
        }

        // --- Create a new log record for invoice + writeOff ---
        function createLogRecord(invoiceId, payload, status, error, writeOffId) {
            try {
                const rec = record.create({ type: CUSTOM_REC, isDynamic: true });
                rec.setValue({ fieldId: 'custrecordrocketlane_inv_id', value: invoiceId });
                if (payload) rec.setValue({ fieldId: 'custrecordrocketlane_response', value: typeof payload === 'string' ? payload : JSON.stringify(payload, null, 1) });
                rec.setValue({ fieldId: 'custrecord_rocketlane_error', value: JSON.stringify(error || '', null, 1) });
                rec.setValue({ fieldId: 'custrecord_rocketlane_status', value: status });
                if (writeOffId) rec.setValue({ fieldId: 'custrecord_write_off_rl_recid', value: writeOffId });
                const id = rec.save({ enableSourcing: false, ignoreMandatoryFields: true });
                return id;
            } catch (e) {
                log.error('createLogRecord Error', e);
                return null;
            }
        }

        // --- Update an existing log's status and/or error ---
        function updateLogStatus(logId, status, error) {
            try {
                const rec = record.load({ type: CUSTOM_REC, id: logId });
                if (typeof status !== 'undefined') rec.setValue({ fieldId: 'custrecord_rocketlane_status', value: status });
                if (typeof error !== 'undefined') rec.setValue({ fieldId: 'custrecord_rocketlane_error', value: JSON.stringify(error || '', null, 1) });
                return rec.save({ enableSourcing: false, ignoreMandatoryFields: true });
            } catch (e) {
                log.error('updateLogStatus Error', e);
                return null;
            }
        }

        // --- Append credit memo to the custrecord_credit_memo_ns field ensuring uniqueness ---
        // function updateLogWithCreditMemo(logId, cmId) {
        //     try {
        //         const rec = record.load({ type: CUSTOM_REC, id: logId });
        //         // read existing value
        //         let current = rec.getValue({ fieldId: 'custrecord_credit_memo_ns' });

        //         // normalise into array of numbers
        //         if (!Array.isArray(current)) current = [current].filter(Boolean);
        //         const clean = current.map(v => parseInt(v, 10)).filter(Boolean);
        //         const newCm = parseInt(cmId, 10);
        //         if (!clean.includes(newCm)) {
        //             clean.push(newCm);
        //             // If field accepts multiselect, pass array. If single-select, pass the single value.
        //             try {
        //                 rec.setValue({ fieldId: 'custrecord_credit_memo_ns', value: clean });
        //             } catch (e) {
        //                 // fallback: write as single latest value
        //                 log.warn('Could not set as array; falling back to set single value', e.message);
        //                 rec.setValue({ fieldId: 'custrecord_credit_memo_ns', value: newCm });
        //             }
        //             rec.setValue({ fieldId: 'custrecord_rocketlane_status', value: STATUS_SUCCESS });
        //             rec.save({ enableSourcing: false, ignoreMandatoryFields: true });
        //             log.audit('Updated custrecord_credit_memo_ns', { logId: logId, creditMemoValues: clean });
        //         } else {
        //             log.audit('Credit Memo already exists on log — skipping duplicate', { logId: logId, cmId: newCm });
        //         }
        //     } catch (e) {
        //         log.error('updateLogWithCreditMemo Error', e);
        //         throw e;
        //     }
        // }

        function updateLogWithCreditMemo(logId, cmId) {
            try {
                if (!logId || !cmId) {
                    log.debug('updateLogWithCreditMemo called with missing params', { logId: logId, cmId: cmId });
                    return null;
                }

                const rec = record.load({ type: CUSTOM_REC, id: logId });
              
                if (cmId) {
                    rec.setValue({ fieldId: "custrecord_rocketlane_error", value: null })
                    rec.setValue({ fieldId: 'custrecord_rocketlane_status', value: STATUS_SUCCESS });
                    rec.setValue({ fieldId: 'custrecord_credit_memo_ns', value: cmId });

                     redirect.toRecord({
                    id: logId,
                    type: CUSTOM_REC
                });
                }

                customId = rec.save({ enableSourcing: false, ignoreMandatoryFields: true });
                log.debug("customId ==>", customId)
                redirect.toRecord({
                    id: customId,
                    type: CUSTOM_REC
                });
                // Normalize current into an array of strings/ids
                // let currentArr = [];
                // if (current === null || typeof current === 'undefined' || current === '') {
                //     currentArr = [];
                // } else if (Array.isArray(current)) {
                //     currentArr = current.slice(); // copy
                // } else if (typeof current === 'string') {
                //     // Could be "123" or "123,456" depending on how the field was stored previously
                //     if (current.indexOf(',') !== -1) {
                //         currentArr = current.split(',').map(s => s.trim()).filter(Boolean);
                //     } else {
                //         currentArr = [current];
                //     }
                // } else {
                //     // any other type (number), coerce to string
                //     currentArr = [String(current)];
                // }

                // Convert to integers where possible and filter invalids
                // const clean = currentArr
                //     .map(v => {
                //         // handle objects that might have .value/.text (rare cases)
                //         if (v && typeof v === 'object' && v.value) return parseInt(v.value, 10);
                //         return parseInt(String(v), 10);
                //     })
                //     .filter(n => !isNaN(n) && n !== 0);

                // const newCm = parseInt(cmId, 10);
                // if (isNaN(newCm) || newCm === 0) {
                //     throw new Error('Invalid cmId passed to updateLogWithCreditMemo: ' + cmId);
                // }

                // if (!clean.includes(newCm)) {
                //     clean.push(newCm);

                //     // Attempt to write as an array (for multiselect fields)
                //     try {
                //         // Only set an array if it has elements; avoid setting empty array which may become null
                //         if (clean.length > 0) {
                //             rec.setValue({ fieldId: 'custrecord_credit_memo_ns', value: clean });
                //         } else {
                //             // fallback set single value
                //             rec.setValue({ fieldId: 'custrecord_credit_memo_ns', value: newCm });
                //         }

                //         // set success status
                //         rec.setValue({ fieldId: 'custrecord_rocketlane_status', value: STATUS_SUCCESS });
                //         // rec.setValue({fieldId:"custrecord_rocketlane_error",value:""})
                //         // try to save
                //         const savedId = rec.save({ enableSourcing: false, ignoreMandatoryFields: true });
                //         log.audit('Updated custrecord_credit_memo_ns (saved as array)', { logId: logId, creditMemoValues: clean, savedId: savedId });
                //         return savedId;
                //     } catch (err) {
                //         // likely a field-type mismatch (single select vs multi-select) or invalid element in the array
                //         log.debug('Failed saving as array, will retry as single value', { err: err.message || err, logId: logId, attemptedValues: clean });

                //         try {
                //             // Reload to clear any partial changes
                //             const rec2 = record.load({ type: CUSTOM_REC, id: logId });
                //             // write the single latest CM id (safe fallback for single-select fields)
                //             rec2.setValue({ fieldId: 'custrecord_credit_memo_ns', value: newCm });
                //             rec2.setValue({ fieldId: 'custrecord_rocketlane_status', value: STATUS_SUCCESS });

                //             const savedId2 = rec2.save({ enableSourcing: false, ignoreMandatoryFields: true });
                //             log.audit('Updated custrecord_credit_memo_ns (saved as single value)', { logId: logId, creditMemoValue: newCm, savedId: savedId2 });
                //             return savedId2;
                //         } catch (err2) {
                //             log.error('Retry writing single value also failed', { err2: err2.message || err2, logId: logId });
                //             throw err2; // rethrow so caller can mark log as failed
                //         }
                //     }
                // } else {
                //     log.audit('Credit Memo already exists on log — skipping duplicate', { logId: logId, cmId: newCm });
                //     return logId;
                // }
            } catch (e) {
                log.error('updateLogWithCreditMemo Error', e);
                throw e;
            }
        }


        // --- Find existing log by invoiceId and (optionally) writeOffId ---
        function findExistingLog(invoiceId, writeOffId) {
            try {
                const filters = [['custrecordrocketlane_inv_id', 'is', invoiceId]];
                if (writeOffId) filters.push('AND', ['custrecord_write_off_rl_recid', 'is', writeOffId]);
                const s = search.create({
                    type: CUSTOM_REC,
                    filters: filters,
                    columns: ['internalid']
                }).run().getRange({ start: 0, end: 1 });
                return s && s.length ? { id: s[0].getValue('internalid') } : null;
            } catch (e) {
                log.error('findExistingLog Error', e);
                return null;
            }
        }

        // --- Find invoice by custom Rocketlane invoice id on invoice record ---
        function findInvoiceByRocketlaneId(rocketlaneInvoiceId) {
            try {
                const s = search.create({
                    type: search.Type.INVOICE,
                    filters: [
                        ['type', 'anyof', 'CustInvc'],
                        'AND',
                        ['custbodyrocketlane_invoice_id', 'is', rocketlaneInvoiceId],
                        'AND',
                        ['mainline', 'is', 'T']
                    ],
                    columns: ['internalid']
                }).run().getRange({ start: 0, end: 1 });
                return s && s.length ? { id: s[0].getValue('internalid') } : null;
            } catch (e) {
                log.error('findInvoiceByRocketlaneId Error', e);
                return null;
            }
        }

        // --- Transform Invoice → Credit Memo ---
        function createCreditMemoFromInvoice(invoiceId, entryDate, amount, paymentId) {
            const cm = record.transform({
                fromType: record.Type.INVOICE,
                fromId: invoiceId,
                toType: record.Type.CREDIT_MEMO,
                isDynamic: true
            });
            cm.setValue({ fieldId: 'customform', value: 178 })
            // set date
            if (entryDate) cm.setValue({ fieldId: 'trandate', value: toDate(entryDate) });
            if (paymentId) cm.setValue({ fieldId: 'custbody_writeoff_id', value: paymentId });

            // set line rate
            if (cm.getLineCount({ sublistId: 'item' }) > 0) {
                cm.selectLine({ sublistId: 'item', line: 0 });
                cm.setCurrentSublistValue({ sublistId: 'item', fieldId: 'rate', value: amount });
                cm.commitLine({ sublistId: 'item' });
            }

            // apply to invoice
            const applyCount = cm.getLineCount({ sublistId: 'apply' });
            for (let i = 0; i < applyCount; i++) {
                const appliedTo = cm.getSublistValue({ sublistId: 'apply', fieldId: 'internalid', line: i });
                if (appliedTo == invoiceId) {
                    cm.selectLine({ sublistId: 'apply', line: i });
                    cm.setCurrentSublistValue({ sublistId: 'apply', fieldId: 'apply', value: true });
                    cm.setCurrentSublistValue({ sublistId: 'apply', fieldId: 'amount', value: amount });
                    cm.commitLine({ sublistId: 'apply' });
                    break;
                }
            }

            return cm.save({ enableSourcing: true, ignoreMandatoryFields: false });
        }

        function toDate(isoDateStr) {
            return isoDateStr ? new Date(new moment(isoDateStr).utcOffset("+05:30")) : null;
        }

        return { onRequest: onRequest };
    });
