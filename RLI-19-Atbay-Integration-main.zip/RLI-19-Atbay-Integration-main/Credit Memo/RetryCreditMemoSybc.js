/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/url'], function (url) {

    function beforeLoad(context) {
        try {
            if (context.type !== "view") {
                return;
            }

            var rec = context.newRecord;
            log.debug("rec", rec)
            var status = rec.getValue({ fieldId: 'custrecord_rocketlane_status' });
            // var rlResponse = rec.getValue({ fieldId: 'custrecord_rl_response' });
            var invoiceId = null;

            // Parse JSON field to extract invoiceId

            // var parsed = JSON.parse(rlResponse);
            var invoiceId = rec.getValue({ fieldId: 'custrecordrocketlane_inv_id' });
            log.debug("invoiceId", invoiceId)

            var cmId = rec.getValue({ fieldId: "custrecord_credit_memo_ns" });
            log.debug("cmId ==>", cmId)

            // Show Retry button only if invoiceId found and status not success (1)
            if (status == 1 && cmId) {
                return;
            }

            // Build Suitelet URL
            var suiteletUrl = url.resolveScript({
                scriptId: 'customscript_rocketlane_credit_memo_sync',      // your Suitelet script id
                deploymentId: 'customdeployrocketlane_credit_memo_sync',  // your Suitelet deploy id
                params: {
                    rec_id: rec.id
                }
            });


            // Add Retry button that opens Suitelet in new tab
            context.form.addButton({
                id: 'custpage_retry_button',
                label: 'Retry',
                functionName: `window.open('${suiteletUrl}', "_self")`
            });

        } catch (e) {
            log.error('Error in beforeLoad', e);
        }
    }

    return {
        beforeLoad: beforeLoad
    };
});
