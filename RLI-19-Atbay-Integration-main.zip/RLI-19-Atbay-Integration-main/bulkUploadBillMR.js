/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
define([
    'N/record',
    'N/search',
    'N/https',
    'N/log'
], (record, search, https, log) => {

    const RL_BASE_URL = 'https://at-bay-test.api.rocketlane.com/api/v1/expenses';
    const RL_API_KEY = 'rl-7d47f3ce-82a2-4825-8f1e-bac8dbabaf6a';

    const buildHeaders = () => ({
        'accept': 'application/json',
        'content-type': 'application/json',
        'api-key': RL_API_KEY
    });

    const toISODate = (value) => {
        if (!value) return null;
        const d = new Date(value);
        return isNaN(d) ? null : d.toISOString().split('T')[0];
    };

    const sendExpenseToRocketlane = (payload) => {
        return https.request({
            method: https.Method.POST,
            url: RL_BASE_URL,
            headers: buildHeaders(),
            body: JSON.stringify(payload)
        });
    };

    /**
     * STEP 1: Find all unsynced Approved Vendor Bills
     */
    const getInputData = () => {
        log.debug("getInput Triggered")
        return search.create({
            type: search.Type.VENDOR_BILL,
            filters: [
                ['mainline', 'is', 'T'], 
                'AND',
                ['custbodysynced_to_rocketlane', 'is', 'F'],
                'AND',
                ['approvalstatus', 'anyof', '2'],   // ✅ Approved
                'AND',
                ["trandate","onorafter","1/31/2026"] // ✅ Your original date filter kept
            ],
            columns: ['internalid']
        });
    };

    /**
     * STEP 2: Process each Vendor Bill
     */
    const map = (context) => {

        log.debug("context",context)

        const searchResult = JSON.parse(context.value);
        log.debug("searchResult",searchResult)

        const billId = searchResult.id;
        let anySuccess = false;

        try {

            const bill = record.load({
                type: record.Type.VENDOR_BILL,
                id: billId,
                isDynamic: false
            });

            const tranDate = toISODate(bill.getValue('trandate'));


            const expenseLineCount = bill.getLineCount({ sublistId: 'expense' }) || 0;
            log.debug("expenseLineCount",expenseLineCount)

            for (let i = 0; i < expenseLineCount; i++) {

                const amount = bill.getSublistValue({
                    sublistId: 'expense',
                    fieldId: 'amount',
                    line: i
                });

                log.debug("expense amount",amount)

                if (!amount || Number(amount) <= 0) continue;
 
                const payload = {
    
    "amount": 44.0,
    "currency": {
        "currencyCode": "USD",
        "currencyName": "US Dollar",
        "currencySymbol": "$"
    },
    "date": "2026-02-17",
    "status": "DRAFT",
    "expenseOwnerId": 600280,
    "projectId": 953296,
    "expenseCategoryId": 629,
    "expenseReportId": 3734,
    "reimbursable": false,
    "reimburseTo": {},
    "billable": true,
    "note": "",
    "attachments": [],
    "createdBy": 600280,
    "createdAt": "2026-02-17T10:25:21.175+0000",
    "updatedAt": "2026-02-17T12:07:48.699+0000",
    "accessFlags": "0010111",
    "fields": [
        {
            "fieldId": 2269384,
            "fieldName": "Memo_2269384",
            "fieldType": "SINGLE_SELECT",
            "fieldDataType": "TEXT",
            "description": "",
            "customField": true,
            "optionsAvailable": false,
            "fieldValue": "hello",
            "userCreated": true,
            "parentFieldName": "meta_data",
            "objectType": "EXPENSE",
            "objectSubType": "DEFAULT",
            "metaData": {
                "options": [],
                "rangeAvailable": false,
                "captureKeyIntervalForFirstActivityOnly": false,
                "allowAdminsAndOwnersToEdit": false,
                "mandatory": false,
                "shouldShowInAddTimeForm": false,
                "isMandatory": false,
                "fieldValueSourceType": "MANUAL",
                "fieldValueSourceFieldInfo": {}
            },
            "fieldLabel": "Memo",
            "createdBy": 602284,
            "isEnabled": true,
            "updatedBy": 602284,
            "updatedAt": 1771318110814,
            "createdAt": 1769706177082,
            "private": false
        },
        {
            "fieldId": 2270224,
            "fieldName": "NSID_2270224",
            "fieldType": "SINGLE_SELECT",
            "fieldDataType": "TEXT",
            "description": "Netsuite Internal ID",
            "customField": true,
            "optionsAvailable": false,
            "fieldValue": "51656",
            "userCreated": true,
            "parentFieldName": "meta_data",
            "objectType": "EXPENSE",
            "objectSubType": "DEFAULT",
            "metaData": {
                "options": [],
                "rangeAvailable": false,
                "captureKeyIntervalForFirstActivityOnly": false,
                "allowAdminsAndOwnersToEdit": false,
                "mandatory": false,
                "shouldShowInAddTimeForm": false,
                "isMandatory": false,
                "fieldValueSourceType": "MANUAL",
                "fieldValueSourceFieldInfo": {}
            },
            "fieldLabel": "NS ID",
            "createdBy": 600280,
            "isEnabled": true,
            "updatedBy": 600280,
            "updatedAt": 1771318110814,
            "createdAt": 1770028034332,
            "private": false
        },
        {
            "fieldId": 2277751,
            "fieldName": "TypeofRecord_2277751",
            "fieldType": "SINGLE_SELECT",
            "fieldDataType": "TEXT",
            "description": "",
            "customField": true,
            "optionsAvailable": false,
            "fieldValue": "bill",
            "userCreated": true,
            "parentFieldName": "meta_data",
            "objectType": "EXPENSE",
            "objectSubType": "DEFAULT",
            "metaData": {
                "options": [],
                "rangeAvailable": false,
                "captureKeyIntervalForFirstActivityOnly": false,
                "allowAdminsAndOwnersToEdit": false,
                "mandatory": false,
                "shouldShowInAddTimeForm": false,
                "isMandatory": false,
                "fieldValueSourceType": "MANUAL",
                "fieldValueSourceFieldInfo": {}
            },
            "fieldLabel": "NS Record Type ",
            "createdBy": 600280,
            "isEnabled": true,
            "updatedBy": 600280,
            "updatedAt": 1771318209910,
            "createdAt": 1771318110166,
            "private": false
        }
    ],
    "projectFinancialsBudgetId": 314608,
    "projectFinancialsBudget": {
        "projectId": 953296,
        "financialContractType": "TIME_AND_MATERIAL",
        "revenueRecognitionType": "ALL_TRACKED_HOURS",
        "currency": {
            "currencyCode": "USD",
            "currencyName": "US Dollar",
            "currencySymbol": "$"
        },
        "projectBudget": 11000.000000,
        "projectMinutes": 2400,
        "projectFinancialsBudgetId": 314608,
        "projectFinancialsBudgetName": "Default Project Budget",
        "startDate": "2025-10-01",
        "endDate": "2026-03-17",
        "fields": [
            {
                "fieldId": 2121816,
                "fieldName": "status",
                "fieldType": "SINGLE_SELECT",
                "fieldDataType": "TEXT",
                "customField": true,
                "optionsAvailable": true,
                "fieldValue": 2,
                "metaFieldValue": {
                    "color": "blue",
                    "label": "Active",
                    "value": 2,
                    "position": 2,
                    "group": 2,
                    "active": true,
                    "deletable": false,
                    "editable": true
                },
                "userCreated": false,
                "parentFieldName": "meta_data",
                "objectType": "PROJECT_FINANCIALS_BUDGET",
                "objectSubType": "DEFAULT",
                "metaData": {
                    "options": [
                        {
                            "color": "cool-gray",
                            "label": "Proposed",
                            "value": 1,
                            "position": 1,
                            "group": 1,
                            "active": true,
                            "deletable": false,
                            "editable": true
                        },
                        {
                            "color": "blue",
                            "label": "Active",
                            "value": 2,
                            "position": 2,
                            "group": 2,
                            "active": true,
                            "deletable": false,
                            "editable": true
                        },
                        {
                            "color": "green",
                            "label": "Completed",
                            "value": 3,
                            "position": 3,
                            "group": 3,
                            "active": true,
                            "deletable": false,
                            "editable": true
                        }
                    ],
                    "visibleOnInvoice": false,
                    "rangeAvailable": false,
                    "captureKeyIntervalForFirstActivityOnly": false,
                    "allowAdminsAndOwnersToEdit": false,
                    "mandatory": false,
                    "default": 1,
                    "shouldShowInAddTimeForm": false,
                    "isMandatory": false
                },
                "fieldColumnName": "status",
                "fieldLabel": "Status",
                "isEnabled": true,
                "createdAt": 1765373277241,
                "private": false
            }
        ],
        "singleBudget": false,
        "invoiced": false,
        "isDefault": true
    },
    "project": {
        "projectName": "Donna's Pet Supplies - Recovery",
        "projectId": 953296,
        "customer": {
            "companyId": 531739,
            "companyName": "Donna's Pet Supplies",
            "identityType": "COMPANY"
        },
        "archived": false,
        "deleted": false
    },
    "expenseOwner": {
        "emailId": "aadhithya.n@prateektechnosoft.com",
        "userId": 600280,
        "firstName": "Aadhithyan",
        "lastName": "N",
        "userType": "NATIVE",
        "company": {
            "companyId": 524671,
            "companyName": "At-bay Security, LLC",
            "companyLogoUrl": "https://d1vtr0p8bkmfca.cloudfront.net/24640/02f1b295-8817-49cb-aa64-2d2a1d60e38d/rocketlane.png",
            "identityType": "COMPANY"
        },
        "role": {
            "roleId": 126264,
            "roleName": "Implementation Manager"
        },
        "userStatus": "ACTIVE",
        "identityType": "USER"
    },
    "expenseCategory": {
        "expenseCategoryId": 629,
        "expenseCategoryName": "Direct Technology Costs (COGS)",
        "billable": true,
        "isDeleted": false
    },
    "expenseReport": {
        "expenseReportId": 3734,
        "expenseReportName": "test",
        "projectId": 953296,
        "expenseOwnerId": 600280,
        "currency": {
            "currencyCode": "USD",
            "currencyName": "US Dollar",
            "currencySymbol": "$"
        },
        "totalAmount": 88.0,
        "expenseReportStatus": "DRAFT",
        "createdAt": "2026-02-17T08:49:08.066+0000",
        "updatedAt": "2026-02-17T12:07:49.034+0000",
        "isDeleted": false
    },
    "createdByUser": {
        "emailId": "aadhithya.n@prateektechnosoft.com",
        "userId": 600280,
        "firstName": "Aadhithyan",
        "lastName": "N",
        "userType": "NATIVE",
        "company": {
            "companyId": 524671,
            "companyName": "At-bay Security, LLC",
            "companyLogoUrl": "https://d1vtr0p8bkmfca.cloudfront.net/24640/02f1b295-8817-49cb-aa64-2d2a1d60e38d/rocketlane.png",
            "identityType": "COMPANY"
        },
        "role": {
            "roleId": 126264,
            "roleName": "Implementation Manager"
        },
        "userStatus": "ACTIVE",
        "identityType": "USER"
    },
    "updatedByUser": {
        "emailId": "aadhithya.n@prateektechnosoft.com",
        "userId": 600280,
        "firstName": "Aadhithyan",
        "lastName": "N",
        "userType": "NATIVE",
        "company": {
            "companyId": 524671,
            "companyName": "At-bay Security, LLC",
            "companyLogoUrl": "https://d1vtr0p8bkmfca.cloudfront.net/24640/02f1b295-8817-49cb-aa64-2d2a1d60e38d/rocketlane.png",
            "identityType": "COMPANY"
        },
        "role": {
            "roleId": 126264,
            "roleName": "Implementation Manager"
        },
        "userStatus": "ACTIVE",
        "identityType": "USER"
    },
    "approvalWorkflowLevels": [],
    "fieldsAccessMeta": {
        "EXPENSE": [
            26
        ]
    },
    "entityToBudgetsMap": {
        "PROJECT": [
            {
                "projectId": 953296,
                "financialContractType": "TIME_AND_MATERIAL",
                "revenueRecognitionType": "ALL_TRACKED_HOURS",
                "currency": {
                    "currencyCode": "USD",
                    "currencyName": "US Dollar",
                    "currencySymbol": "$"
                },
                "projectBudget": 11000.000000,
                "projectMinutes": 2400,
                "projectFinancialsBudgetId": 314608,
                "projectFinancialsBudgetName": "Default Project Budget",
                "startDate": "2025-10-01",
                "endDate": "2026-03-17",
                "fields": [
                    {
                        "fieldId": 2121816,
                        "fieldName": "status",
                        "fieldType": "SINGLE_SELECT",
                        "fieldDataType": "TEXT",
                        "customField": true,
                        "optionsAvailable": true,
                        "fieldValue": 2,
                        "metaFieldValue": {
                            "color": "blue",
                            "label": "Active",
                            "value": 2,
                            "position": 2,
                            "group": 2,
                            "active": true,
                            "deletable": false,
                            "editable": true
                        },
                        "userCreated": false,
                        "parentFieldName": "meta_data",
                        "objectType": "PROJECT_FINANCIALS_BUDGET",
                        "objectSubType": "DEFAULT",
                        "metaData": {
                            "options": [
                                {
                                    "color": "cool-gray",
                                    "label": "Proposed",
                                    "value": 1,
                                    "position": 1,
                                    "group": 1,
                                    "active": true,
                                    "deletable": false,
                                    "editable": true
                                },
                                {
                                    "color": "blue",
                                    "label": "Active",
                                    "value": 2,
                                    "position": 2,
                                    "group": 2,
                                    "active": true,
                                    "deletable": false,
                                    "editable": true
                                },
                                {
                                    "color": "green",
                                    "label": "Completed",
                                    "value": 3,
                                    "position": 3,
                                    "group": 3,
                                    "active": true,
                                    "deletable": false,
                                    "editable": true
                                }
                            ],
                            "visibleOnInvoice": false,
                            "rangeAvailable": false,
                            "captureKeyIntervalForFirstActivityOnly": false,
                            "allowAdminsAndOwnersToEdit": false,
                            "mandatory": false,
                            "default": 1,
                            "shouldShowInAddTimeForm": false,
                            "isMandatory": false
                        },
                        "fieldColumnName": "status",
                        "fieldLabel": "Status",
                        "isEnabled": true,
                        "createdAt": 1765373277241,
                        "private": false
                    }
                ],
                "singleBudget": false,
                "invoiced": false,
                "isDefault": true
            }
        ]
    }
}
                // const payload = {
                //     amount: Number(amount),
                //     currency: {
                //         currencyCode: "USD",
                //         currencyName: "US Dollar",
                //         currencySymbol: "$"
                //     },
                //     date: tranDate, // ✅ Using bill trandate
                //     status: 'DRAFT',
                //     expenseOwnerId: 600280,
                //     projectId: 953296,
                //     expenseCategoryId: 629,
                //     expenseReportId: 3484,
                //     reimbursable: false,
                //     billable: true,
                //     note: "",
                //     attachments: [],
                //     fields: [
                //         {
                //             fieldId: 2269384,
                //             fieldValue: bill.getSublistValue({
                //                 sublistId: 'expense',
                //                 fieldId: 'memo',
                //                 line: i
                //             }) || ''
                //         },
                //         {
                //             fieldId: 2270224,
                //             fieldValue: billId
                //         }
                //     ],
                //     projectFinancialsBudgetId: 314608
                // };
                log.debug("payload",payload)
                const resp = sendExpenseToRocketlane(payload);

                if (resp && (resp.code === 200 || resp.code === 201)) {
                    anySuccess = true;
                } else {
                    log.error('Rocketlane Error - Expense Line', {
                        billId,
                        line: i,
                        response: resp
                    });
                }
            }


            const itemLineCount = bill.getLineCount({ sublistId: 'expense' }) || 0;
            log.debug("itemLineCount",itemLineCount)

            for (let j = 0; j < itemLineCount; j++) {

                const amount = bill.getSublistValue({
                    sublistId: 'expense',
                    fieldId: 'amount',
                    line: j
                });

                log.debug("item amount",amount)

                if (!amount || Number(amount) <= 0) continue;

                const payload = {
                    amount: Number(amount),
                    currency: {
                        currencyCode: "USD",
                        currencyName: "US Dollar",
                        currencySymbol: "$"
                    },
                    date: tranDate,
                    status: 'DRAFT',
                    expenseOwnerId: 600280,
                    projectId: 953296,
                    expenseCategoryId: 629,
                    expenseReportId: 3484,
                    reimbursable: false,
                    billable: true,
                    note: "",
                    attachments: [],
                    fields: [
                        {
                            fieldId: 2269384,
                            fieldValue: bill.getSublistValue({
                                sublistId: 'item',
                                fieldId: 'description',
                                line: j
                            }) || ''
                        },
                        {
                            fieldId: 2270224,
                            fieldValue: billId
                        }
                    ],
                    projectFinancialsBudgetId: 314608
                };

                const resp = sendExpenseToRocketlane(payload);

                if (resp && (resp.code === 200 || resp.code === 201)) {
                    anySuccess = true;
                } else {
                    log.error('Rocketlane Error - Item Line', {
                        billId,
                        line: j,
                        response: resp
                    });
                }
            }

            if (anySuccess) {
                context.write({
                    key: billId,
                    value: true
                });
            }

        } catch (e) {
            log.error('Map Error', { billId, error: e });
        }
    };

    /**
     * STEP 3: Mark Vendor Bill as synced
     */
    const reduce = (context) => {

        const billId = context.key;

        try {

            record.submitFields({
                type: record.Type.VENDOR_BILL,
                id: billId,
                values: {
                    custbodysynced_to_rocketlane: true
                },
                options: {
                    enableSourcing: false,
                    ignoreMandatoryFields: true
                }
            });

            log.debug('Vendor Bill Synced', billId);

        } catch (e) {
            log.error('Reduce Error', { billId, error: e });
        }
    };

    return {
        getInputData,
        map,
        reduce
    };
});
