/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
define([
    'N/record',
    'N/search',
    'N/https',
    'N/log'
], (record, search, https, log) => {

    const RL_BASE_URL = 'https://at-bay-test.api.rocketlane.com/api/v1/expenses';
    const RL_API_KEY = 'rl-7d47f3ce-82a2-4825-8f1e-bac8dbabaf6a';

    const buildHeaders = () => ({
        'accept': 'application/json',
        'content-type': 'application/json',
        'api-key': RL_API_KEY
    });

    const toISODate = (value) => {
        if (!value) return null;
        const d = new Date(value);
        return isNaN(d) ? null : d.toISOString().split('T')[0];
    };

    const sendExpenseToRocketlane = (payload) => {
        return https.request({
            method: https.Method.POST,
            url: RL_BASE_URL,
            headers: buildHeaders(),
            body: JSON.stringify(payload)
        });
    };

    /**
     * STEP 1: Find all unsynced Expense Reports
     */
  const getInputData = () => {
    log.debug("getInput Triggererd")
    return search.create({
        type: search.Type.EXPENSE_REPORT,
        filters: [
            ['mainline', 'is', 'T'], 
            'AND',
            ['custbodysynced_to_rocketlane', 'is', 'F'],
            'AND',
             ["status","anyof","ExpRept:F"], 
            "AND", 
            ["trandate","onorafter","1/31/2026"]
        ],
        columns: ['internalid']
    });
    
};


    /**
     * STEP 2: Process each Expense Report
     */
    const map = (context) => {
            log.debug("context",context)
        const searchResult = JSON.parse(context.value);
        log.debug("searchResult",searchResult)
        const expenseReportId = searchResult.id;

        let anySuccess = false;

        try {
            const expRep = record.load({
                type: record.Type.EXPENSE_REPORT,
                id: expenseReportId,
                isDynamic: false
            });

            const lineCount = expRep.getLineCount({ sublistId: 'expense' }) || 0;
              log.debug("linecount",lineCount)
            for (let i = 0; i < lineCount; i++) {

                const amount = expRep.getSublistValue({
                    sublistId: 'expense',
                    fieldId: 'amount',
                    line: i
                });
log.debug("amount",amount)
                if (!amount || Number(amount) <= 0) continue;

                const payload = {
                    amount: Number(amount),
                    currency: {
                        currencyCode: "USD",
                        currencyName: "US Dollar",
                        currencySymbol: "$"
                    },
                    date: toISODate(
                        expRep.getSublistValue({
                            sublistId: 'expense',
                            fieldId: 'expensedate',
                            line: i
                        })
                    ),
                    status: 'DRAFT',
                    expenseOwnerId: 600280,
                    projectId: 953296,
                    expenseCategoryId: 629,
                    expenseReportId: 3484,
                    reimbursable: false,
                    billable: true,
                    note: "",
                    attachments: [],
                      fields: [
        {
            fieldId: 2269384,   // Memo field ID
            fieldValue: expRep.getSublistValue({
                        sublistId: 'expense',
                        fieldId: 'memo',
                        line: i
                    }) || ''
        },
           {
            fieldId: 2270224,   // Memo field ID
            fieldValue: expenseReportId
        }
    ],
                    projectFinancialsBudgetId: 314608
                };

                const resp = sendExpenseToRocketlane(payload);

                if (resp && (resp.code === 200 || resp.code === 201)) {
                    anySuccess = true;
                } else {
                    log.error('Rocketlane Error', {
                        expenseReportId,
                        line: i,
                        response: resp
                    });
                }
            }

            if (anySuccess) {
                context.write({
                    key: expenseReportId,
                    value: true
                });
            }

        } catch (e) {
            log.error('Map Error', { expenseReportId, error: e });
        }
    };

    /**
     * STEP 3: Mark Expense Report as synced
     */
    const reduce = (context) => {
        const expenseReportId = context.key;

        try {
            record.submitFields({
                type: record.Type.EXPENSE_REPORT,
                id: expenseReportId,
                values: {
                    custbodysynced_to_rocketlane: true
                },
                options: {
                    enableSourcing: false,
                    ignoreMandatoryFields: true
                }
            });

            log.debug('Expense Report Synced', expenseReportId);

        } catch (e) {
            log.error('Reduce Error', { expenseReportId, error: e });
        }
    };

    return {
        getInputData,
        map,
        reduce
    };
});
